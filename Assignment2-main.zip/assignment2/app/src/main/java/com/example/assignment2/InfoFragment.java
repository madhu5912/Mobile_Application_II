package com.example.assignment2;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class InfoFragment extends Fragment {

    int companyID;
    int modelID;

    InfoFragment(int companyID, int modelID){
        this.companyID = companyID;
        this.modelID = modelID;
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup viewgrp, Bundle s) {
        super.onCreateView(inflater, viewgrp, s);
        View view = inflater.inflate(R.layout.layout_carinfo, viewgrp, false);
        TextView tv = view.findViewById(R.id.car_info);
        String stringRef = "car"+companyID+"_"+modelID;
        Log.d("MESSAGE", stringRef);
        int strID = getResources().getIdentifier(stringRef, "string", "com.example.assignment2");
        Log.d("STRID", Integer.toString(strID));
        Log.d("STRVAL", getResources().getString(strID));
        tv.setText(getResources().getString(strID));
        return view;
    }
}
