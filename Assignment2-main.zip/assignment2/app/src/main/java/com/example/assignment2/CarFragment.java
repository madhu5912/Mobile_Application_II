package com.example.assignment2;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


public class CarFragment extends Fragment {
    String[][] modelNames = {     // String Array that'll be holding our modelNames
            {"Tigor", "Nexon", "Altroz", "Indica"},
            {"Ciaz", "Baleno", "Alto 800", "WagonR"},
            {"XUV 500", "Scorpio", "Thar", "XUV 300"}
    };
    int companyID;

    CarFragment(int companyID){   // constructor
        this.companyID = companyID;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup viewgrp, Bundle b){
        super.onCreateView(inflater, viewgrp, b);
        View view = inflater.inflate(R.layout.layout_car_models, viewgrp, false);
        int[] textViews = {R.id.textView1, R.id.textView2, R.id.textView3, R.id.textView4};
        for(int i=0; i<textViews.length; i++) {
            int iVal = i;
            TextView tv = (TextView) view.findViewById(textViews[i]);
            tv.setText(modelNames[companyID][i]);
            tv.setOnClickListener(v -> {
                modelSelected(companyID, iVal);
            });
        }
        return view;
    }

    void modelSelected(int companyID, int modelID){
        FragmentManager fragMan = getParentFragmentManager();
        FragmentTransaction fragTran = fragMan.beginTransaction();
        fragTran.replace(R.id.model_description, new InfoFragment(companyID, modelID));
        fragTran.commit();
    }
}

