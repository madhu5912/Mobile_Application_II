package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Setting listeners for all the company named buttons
        int[] buttonArr = { R.id.button_tata, R.id.button_suzuki, R.id.button_mahindra};
        for(int i=0; i<buttonArr.length; i++) {
            int iVal = i;
            findViewById(buttonArr[i]).setOnClickListener(v -> {
                companySelected(iVal);
            });
        }
    }



    void companySelected(int companyID){
        FragmentManager fragMan = getSupportFragmentManager();
        FragmentTransaction fragTran = fragMan.beginTransaction();
        fragTran.replace(R.id.model_names, new CarFragment(companyID));
        fragTran.commit();
        }


}

